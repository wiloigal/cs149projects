// Title: process class
// Programer: Haoyang Liu
// Date: 10/01/2017
/** Introduction **
 * process class with attributes: arrival time, expected run time, priority level, 
 * and a boolean value indicating if job is processed or not. 
 * Setters and Getters
 * */
public class process 
{
	private char[] name = new char [2];
	private int arrivalTime;
	private float expectedRunTime;
	private int priority;
	private float turnaroundTime;
	private float responseTime;
	private float waitTime;
	private boolean isJobDone;
	
	public process(char[] newName, int newArrival,float newRuntime,int newPriority,float newTurnaroundTime,float newResponseTime)
	{
		setName(newName);
		setArrivalTime(newArrival);
		setRuntime(newRuntime);
		setPriority(newPriority);
		this.setTurnaroundTime(newTurnaroundTime);
		this.setResponseTime(newResponseTime);
		isJobDone = false;
	}
	
	public String Name() 
	{ 
		return String.valueOf(name); 
	}
	public void setName(char[] newName) 
	{ 
		for(int i = 0;i<newName.length;i++)
		{
			name[i] = newName[i];
		}
	}
	
	public int ArrivalTime() { return arrivalTime; }
	public void setArrivalTime(int newArrival) { this.arrivalTime = newArrival; }
	
	public float Runtime(){ return expectedRunTime; }
	public void setRuntime(float newRuntime) { this.expectedRunTime = newRuntime; }
	
	public int Priority(){ return priority; }
	public void setPriority(int newPriority) { this.priority = newPriority; }
	
	public float TurnaroundTime(){ return turnaroundTime; }
	public void setTurnaroundTime(float newTurnaroundTime) { this.turnaroundTime = newTurnaroundTime; }
	
	public float ResponseTime(){ return responseTime; }
	public void setResponseTime(float newResponseTime) { this.responseTime = newResponseTime; }
	
	public boolean IsJobDone(){ return isJobDone; }
	public void markJobDone() { isJobDone = true; }
	
	public float WaitTime() { return turnaroundTime - expectedRunTime;}
}
